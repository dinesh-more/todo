package com.rest.api.todo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;
import java.util.Objects;

@Entity
public class Todo {
	
	@Id
	@GeneratedValue
	private long id;
	private String username;
	private String description;
	private Date date;
	private boolean progress;

	public Todo() {
	}

	public Todo(long id, String username, String description, Date date, boolean progress) {
		this.id = id;
		this.username = username;
		this.description = description;
		this.date = date;
		this.progress = progress;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public boolean isProgress() {
		return progress;
	}

	public void setProgress(boolean progress) {
		this.progress = progress;
	}

	@Override
	public String toString() {
		return "Todo{" +
				"id=" + id +
				", username='" + username + '\'' +
				", description='" + description + '\'' +
				", date=" + date +
				", progress=" + progress +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Todo todo = (Todo) o;
		return id == todo.id;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
}
