import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from '../list-to-do/list-to-do.component';
import { TododataService } from '../service/data/tododata.service';

@Component({
  selector: 'app-updatetodo',
  templateUrl: './updatetodo.component.html',
  styleUrls: ['./updatetodo.component.css'],
})
export class UpdatetodoComponent implements OnInit {
  id: number = 0;
  todo: any = {};

  constructor(
    private todoService: TododataService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];

    this.todo = new Todo(this.id, 'Dinesh', '', false, new Date());

    if (this.id != -1) {
      this.todoService
        .getTodo(this.todo.username, this.todo.id)
        .subscribe((data) => {
          this.todo = data;
        });
    }
  }

  updateTodo() {
    // if(this.id == -1) { //=== ==
    //   this.todoService.createTodo('in28minutes', this.todo)
    //       .subscribe (
    //         data => {
    //           console.log(data)
    //           this.router.navigate(['todos'])
    //         }
    //       )
    // } else {
      this.todoService.updateTodo(this.todo.username, this.todo.id, this.todo)
          .subscribe (
            data => {
              console.log(data)
              this.router.navigate(['todos'])
            }
          )
    // }
  }
}
