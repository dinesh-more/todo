import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TododataService } from '../service/data/tododata.service';

export class Todo {
  constructor(
    public id: number,
    public username: string,
    public description: string,
    public progress: boolean,
    public date: Date
  ) {}
}

@Component({
  selector: 'app-list-todos',
  templateUrl: './list-to-do.component.html',
  styleUrls: ['./list-to-do.component.css'],
})
export class ListTodoComponent implements OnInit {
  // todos = [
  //   new Todo(1, 'Learn to Dance', false, new Date()),
  //   new Todo(2, 'Become an Expert at Angular', false, new Date()),
  //   new Todo(3, 'Visit India', false, new Date()),
  // ];
  todos: Todo[] = [];

  message: string = '';

  constructor(
    private router: Router,
    private todoDataService: TododataService
  ) {}

  ngOnInit() {
    this.getAllTodos();
  }

  getAllTodos() {
    let username = sessionStorage.getItem('authenticatedUser');
    this.todoDataService.getAllTodos(username).subscribe(
      (response) => {
        this.todos = response;
      },
      (error) => {
        this.todos = error;
      }
    );
  }

  addTodo() {
    this.router.navigate(['add-todo']);
  }

  updateTodo(username: any, id: any) {
    // alert('Selected id: ' + id + ' and Username: ' + username);
    this.router.navigate(['todos', id]);
  }

  deleteTodo(username: any, id: any) {
    this.todoDataService.deleteTodo(username, id).subscribe(
      (response) => {
        this.message = `Todo ${id} Deleted Successfully`;
        // window.location.reload();
        this.getAllTodos();
      },
      (error) => {
        // alert('Unable to Delete todo: ' + error);
        this.message = JSON.stringify(error.message);
      }
    );
  }
}
