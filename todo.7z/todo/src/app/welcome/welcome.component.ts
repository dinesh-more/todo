import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WelcomedataService } from '../service/data/welcomedata.service';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css'],
})
export class WelcomeComponent implements OnInit {
  name = '';

  welcomeMessageFromBackend: any = {};

  isContentMessage: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private welcomeService: WelcomedataService
  ) {}

  // void init() {
  ngOnInit() {
    this.name = this.route.snapshot.params['name'];
  }

  getWelcomeMessage() {
    this.welcomeService.getHelloWorld().subscribe(
      (response) => {
        this.isContentMessage = true;
        this.welcomeMessageFromBackend = response.message;
      },
      (error) => {
        this.isContentMessage = true;
        this.welcomeMessageFromBackend = error.error.message;
      }
    );
  }

  getHelloWorldWithParameter() {
    this.welcomeService.getHelloWorldWithParameter(this.name).subscribe(
      (response) => this.handleSuccessfulResponse(response),
      (error) => this.handleErrorResponse(error)
    );
  }

  handleSuccessfulResponse(response: any) {
    this.isContentMessage = true;
    this.welcomeMessageFromBackend = response.message;
  }

  handleErrorResponse(error: any) {
    this.isContentMessage = true;
    this.welcomeMessageFromBackend = error.error.message;
  }
}
