import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from '../list-to-do/list-to-do.component';
import { TododataService } from '../service/data/tododata.service';

@Component({
  selector: 'app-addtodo',
  templateUrl: './addtodo.component.html',
  styleUrls: ['./addtodo.component.css'],
})
export class AddtodoComponent implements OnInit {
  id: number = 0;
  todo: any = {};

  constructor(
    private todoService: TododataService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.todo = new Todo(this.id, '', '', false, new Date());
  }

  addTodo() {
    this.todoService
      .addTodo(sessionStorage.getItem('authenticatedUser'), this.todo)
      .subscribe((data) => {
        console.log(data);
        this.router.navigate(['todos']);
      });
  }
}
