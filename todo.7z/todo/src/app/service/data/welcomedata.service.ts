import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_URL } from 'src/app/app.constants';

export class HelloWorldbean {
  constructor(public message: string) {}
}

@Injectable({
  providedIn: 'root',
})
export class WelcomedataService {
  constructor(private http: HttpClient) {}

  getHelloWorld() {
    return this.http.get<HelloWorldbean>(
      `${API_URL}/hello-world-bean`
    );
  }

  getHelloWorldWithParameter(name: string) {
    // let basicAuthHeader = this.createBasicAuthenticationHeader();
    // let headers = new HttpHeaders({
    //   Authorization: basicAuthHeader,
    // });
    return this.http.get(`${API_URL}/hello-world-bean/${name}`,
    // {headers}
    );
  }

}
