import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JPA_API_URL } from 'src/app/app.constants';
import { Todo } from 'src/app/list-to-do/list-to-do.component';

@Injectable({
  providedIn: 'root',
})
export class TododataService {
  constructor(private http: HttpClient) {}

  getAllTodos(username: any) {
    return this.http.get<Todo[]>(
      `${JPA_API_URL}/users/${username}/todos`
    );
  }

  getTodo(username: any, id: any) {
    return this.http.get(`${JPA_API_URL}/users/${username}/todos/${id}`);
  }

  updateTodo(username: any, id: any, todo: any) {
    return this.http.put(
      `${JPA_API_URL}/users/${username}/todos/${id}`,
      todo
    );
  }

  addTodo(username: any, todo: any) {
    return this.http.post(
      `${JPA_API_URL}/users/${username}/todos`,
      todo
    );
  }

  deleteTodo(username: any, id: any) {
    return this.http.delete(
      `${JPA_API_URL}/users/${username}/todos/${id}`
    );
  }
}
